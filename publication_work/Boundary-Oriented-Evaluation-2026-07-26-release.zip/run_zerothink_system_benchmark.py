#!/usr/bin/env python3
"""ZeroThink public system benchmark.

This is a smoke/behavior benchmark for the ZeroThink web/API system. It does
not use account cookies, live provider keys, or private server credentials.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import statistics
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


RUN_DATE = "2026-07-09"
BASE_URL = "https://zerothink.talktoai.org"
ITERATIONS = 3
TIMEOUT_SECONDS = 25

SCRIPT_DIR = Path(__file__).resolve().parent
WORKSPACE_DIR = SCRIPT_DIR.parent
ZEROTHINK_DIR = WORKSPACE_DIR / "ZeroThink"
RESEARCH_DIR = WORKSPACE_DIR / "research-github"
WORK_RESULTS_DIR = SCRIPT_DIR / "zerothink-system-results"
PUBLIC_RESULTS_DIR = RESEARCH_DIR / "data" / "benchmarks"

USER_AGENT = "ZeroThinkSystemBenchmark/2026-07-09"


SECRET_PATTERNS = {
    "openzero_api_key_literal": re.compile(r"OPENZERO_API_KEY", re.I),
    "server_password_literal": re.compile(r"SUDO_PASS", re.I),
    "openzero_machine_key": re.compile(r"\boz_[A-Za-z0-9_-]{12,}\b"),
    "openai_key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b"),
    "github_token": re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
    "huggingface_token": re.compile(r"\bhf_[A-Za-z0-9]{20,}\b"),
    "google_api_key": re.compile(r"\bAIza[0-9A-Za-z_-]{20,}\b"),
    "bearer_token": re.compile(r"\bBearer\s+[A-Za-z0-9._-]{24,}\b", re.I),
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dirs() -> None:
    WORK_RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PUBLIC_RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def sanitize_detail(value: Any) -> Any:
    """Remove transient credentials/codes from public details."""

    if isinstance(value, dict):
        cleaned = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if lowered in {
                "device_code",
                "user_code",
                "access_token",
                "token",
                "token_hint",
                "key",
                "api_key",
                "authorization",
            }:
                cleaned[key] = "<redacted>"
            else:
                cleaned[key] = sanitize_detail(item)
        return cleaned
    if isinstance(value, list):
        return [sanitize_detail(item) for item in value]
    if isinstance(value, str):
        text = value
        text = re.sub(r"\boz_[A-Za-z0-9_-]{6,}\b", "<redacted-openzero-key>", text)
        text = re.sub(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{8,}\b", "<redacted-openai-key>", text)
        text = re.sub(r"\bhf_[A-Za-z0-9]{8,}\b", "<redacted-hf-token>", text)
        text = re.sub(r"\bgh[pousr]_[A-Za-z0-9_]{8,}\b", "<redacted-github-token>", text)
        text = re.sub(r"\bBearer\s+[A-Za-z0-9._-]{8,}\b", "Bearer <redacted>", text, flags=re.I)
        return text
    return value


def secret_hits(text: str) -> list[str]:
    hits: list[str] = []
    for name, pattern in SECRET_PATTERNS.items():
        if pattern.search(text):
            hits.append(name)
    return hits


def elapsed_request(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    accept: str = "application/json,text/html;q=0.9,*/*;q=0.8",
) -> dict[str, Any]:
    url = urllib.parse.urljoin(BASE_URL + "/", path.lstrip("/"))
    body = None
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": accept,
        "Cache-Control": "no-cache",
    }
    if payload is not None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, method=method.upper(), headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            raw = response.read()
            status = int(response.status)
            content_type = response.headers.get("content-type", "")
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        status = int(exc.code)
        content_type = exc.headers.get("content-type", "") if exc.headers else ""
    except Exception as exc:  # Network failures are benchmark results too.
        latency = time.perf_counter() - started
        return {
            "status": 0,
            "latency": latency,
            "body": "",
            "content_type": "",
            "error": f"{type(exc).__name__}: {exc}",
            "url": url,
        }
    latency = time.perf_counter() - started
    text = raw.decode("utf-8", errors="replace")
    return {
        "status": status,
        "latency": latency,
        "body": text,
        "content_type": content_type,
        "error": "",
        "url": url,
    }


def parse_json(text: str) -> dict[str, Any]:
    try:
        value = json.loads(text)
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def extract_title(html: str) -> str:
    match = re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.I | re.S)
    if not match:
        return ""
    return re.sub(r"\s+", " ", match.group(1)).strip()


def add_result(
    rows: list[dict[str, Any]],
    category: str,
    test: str,
    target: str,
    expected: str,
    observed: str,
    passed: bool,
    latency_seconds: float | None = None,
    details: dict[str, Any] | None = None,
    sensitive_hits: list[str] | None = None,
) -> None:
    rows.append(
        {
            "run_date": RUN_DATE,
            "category": category,
            "test": test,
            "target": target,
            "expected": expected,
            "observed": observed,
            "passed": "yes" if passed else "no",
            "latency_seconds": "" if latency_seconds is None else f"{latency_seconds:.6f}",
            "secret_hits": ",".join(sorted(set(sensitive_hits or []))),
            "details_json": json.dumps(sanitize_detail(details or {}), ensure_ascii=True, sort_keys=True),
        }
    )


def benchmark_public_pages(rows: list[dict[str, Any]]) -> dict[str, Any]:
    page_specs = [
        ("/", 200, ["ZeroThink"]),
        ("/research-paper-creator", 200, ["Research Paper Creator", "paper_creator_action"]),
        ("/research", 200, ["ZeroThink", "Research"]),
        ("/faq", 200, ["ZeroThink"]),
        ("/docs", 200, ["ZeroThink"]),
        ("/cli/connect", 200, ["ZeroThink"]),
    ]
    summary: dict[str, Any] = {"pages": []}
    for path, expected_status, markers in page_specs:
        probes = [elapsed_request("GET", path, accept="text/html,*/*") for _ in range(ITERATIONS)]
        statuses = [probe["status"] for probe in probes]
        latencies = [float(probe["latency"]) for probe in probes]
        body = probes[0].get("body", "")
        hits = sorted({hit for probe in probes for hit in secret_hits(str(probe.get("body", "")))})
        title = extract_title(body)
        marker_pass = all(marker in body for marker in markers)
        status_pass = all(status == expected_status for status in statuses)
        pass_ok = status_pass and marker_pass and not hits
        mean_latency = statistics.mean(latencies)
        observed = f"statuses={statuses}; title={title or 'n/a'}; markers={marker_pass}"
        details = {
            "status_codes": statuses,
            "title": title,
            "required_markers": markers,
            "latency_mean": mean_latency,
            "latency_min": min(latencies),
            "latency_max": max(latencies),
            "content_type": probes[0].get("content_type", ""),
        }
        add_result(
            rows,
            "public_page",
            f"GET {path}",
            path,
            f"{expected_status} with markers and no token-like leaks",
            observed,
            pass_ok,
            mean_latency,
            details,
            hits,
        )
        summary["pages"].append(details | {"path": path, "passed": pass_ok})
    return summary


def benchmark_cli_api(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {"tests": []}

    def record(name: str, payload: dict[str, Any], expected_status: int, expected_status_field: str) -> dict[str, Any]:
        probe = elapsed_request("POST", "/api_cli.php", payload)
        decoded = parse_json(probe["body"])
        hits = secret_hits(probe["body"])
        status_field = str(decoded.get("status", ""))
        pass_ok = probe["status"] == expected_status and status_field == expected_status_field and not hits
        details = {
            "http_status": probe["status"],
            "json_status": status_field,
            "json_keys": sorted(decoded.keys()),
            "message": decoded.get("message", ""),
        }
        add_result(
            rows,
            "cli_api",
            name,
            "/api_cli.php",
            f"HTTP {expected_status}, status={expected_status_field}",
            f"HTTP {probe['status']}, status={status_field}",
            pass_ok,
            float(probe["latency"]),
            details,
            hits,
        )
        summary["tests"].append(details | {"name": name, "passed": pass_ok})
        return decoded

    record("missing action guard", {}, 400, "error")
    record("missing device code guard", {"action": "device_poll"}, 400, "error")
    record("unauthenticated me guard", {"action": "me"}, 403, "error")
    record("unknown protected action auth guard", {"action": "not_a_real_action"}, 403, "error")

    start_payload = {
        "action": "device_start",
        "label": "ZeroThink public system benchmark",
        "platform": "codex-windows",
        "hostname": "benchmark-host",
        "cwd": "model-benchmark-work",
        "version": f"benchmark-{RUN_DATE}",
    }
    start_probe = elapsed_request("POST", "/api_cli.php", start_payload)
    start_json = parse_json(start_probe["body"])
    start_hits = secret_hits(start_probe["body"])
    required_fields = ["device_code", "user_code", "verification_url", "expires_at", "expires_in", "interval"]
    field_presence = {f"has_{field}": field in start_json and bool(start_json.get(field)) for field in required_fields}
    start_pass = (
        start_probe["status"] == 200
        and start_json.get("status") == "success"
        and all(field_presence.values())
        and str(start_json.get("verification_url", "")).startswith(BASE_URL + "/cli/connect")
        and not start_hits
    )
    add_result(
        rows,
        "cli_api",
        "device_start handshake",
        "/api_cli.php",
        "HTTP 200 success with device login fields",
        f"HTTP {start_probe['status']}, fields={field_presence}",
        start_pass,
        float(start_probe["latency"]),
        {
            "http_status": start_probe["status"],
            "json_status": start_json.get("status", ""),
            "field_presence": field_presence,
            "expires_in": start_json.get("expires_in"),
            "interval": start_json.get("interval"),
            "verification_url_host_ok": str(start_json.get("verification_url", "")).startswith(BASE_URL),
        },
        start_hits,
    )
    summary["tests"].append({"name": "device_start handshake", "passed": start_pass, "field_presence": field_presence})

    if start_json.get("device_code"):
        poll_probe = elapsed_request("POST", "/api_cli.php", {"action": "device_poll", "device_code": start_json["device_code"]})
        poll_json = parse_json(poll_probe["body"])
        poll_hits = secret_hits(poll_probe["body"])
        poll_pass = poll_probe["status"] == 202 and poll_json.get("status") == "authorization_pending" and not poll_hits
        add_result(
            rows,
            "cli_api",
            "device_poll pending state",
            "/api_cli.php",
            "HTTP 202 authorization_pending before browser approval",
            f"HTTP {poll_probe['status']}, status={poll_json.get('status', '')}",
            poll_pass,
            float(poll_probe["latency"]),
            {
                "http_status": poll_probe["status"],
                "json_status": poll_json.get("status", ""),
                "message": poll_json.get("message", ""),
            },
            poll_hits,
        )
        summary["tests"].append({"name": "device_poll pending state", "passed": poll_pass})

    return summary


def benchmark_agent_api(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {"tests": []}

    agent_tests = [
        {
            "name": "unauthenticated OpenZero generation guard",
            "payload": {
                "prompt": "Say READY only.",
                "engine": "zerothink",
                "model": "openzero-fast",
                "zero_mode": True,
            },
            "expected_status": 403,
            "expected_json_status": "error",
            "required_reply_marker": "Auth or supported direct key mode required",
        },
        {
            "name": "OpenZero direct-mode unsupported guard",
            "payload": {
                "prompt": "who are you?",
                "engine": "zerothink",
                "model": "openzero-fast",
                "direct_mode": True,
                "key": "benchmark-fake-key",
            },
            "expected_status": 403,
            "expected_json_status": "error",
            "required_reply_marker": "Auth or supported direct key mode required",
        },
        {
            "name": "direct identity local branch",
            "payload": {
                "prompt": "who are you?",
                "engine": "groq",
                "model": "llama-3.1-8b-instant",
                "direct_mode": True,
                "key": "benchmark-fake-key",
            },
            "expected_status": 200,
            "expected_json_status": "success",
            "required_reply_marker": "Zero Direct",
        },
        {
            "name": "direct capabilities local branch",
            "payload": {
                "prompt": "what can you do?",
                "engine": "groq",
                "model": "llama-3.1-8b-instant",
                "direct_mode": True,
                "key": "benchmark-fake-key",
            },
            "expected_status": 200,
            "expected_json_status": "success",
            "required_reply_marker": "Limits in direct mode",
        },
    ]

    for spec in agent_tests:
        probe = elapsed_request("POST", "/api_agent.php", spec["payload"])
        decoded = parse_json(probe["body"])
        hits = secret_hits(probe["body"])
        reply = str(decoded.get("reply", ""))
        observed_status = str(decoded.get("status", ""))
        pass_ok = (
            probe["status"] == spec["expected_status"]
            and observed_status == spec["expected_json_status"]
            and spec["required_reply_marker"] in reply
            and not hits
        )
        details = {
            "http_status": probe["status"],
            "json_status": observed_status,
            "provider": decoded.get("provider", ""),
            "model": decoded.get("model", ""),
            "reply_marker_found": spec["required_reply_marker"] in reply,
            "reply_length": len(reply),
        }
        add_result(
            rows,
            "agent_api",
            spec["name"],
            "/api_agent.php",
            f"HTTP {spec['expected_status']}, status={spec['expected_json_status']}, marker",
            f"HTTP {probe['status']}, status={observed_status}, reply_len={len(reply)}",
            pass_ok,
            float(probe["latency"]),
            details,
            hits,
        )
        summary["tests"].append(details | {"name": spec["name"], "passed": pass_ok})

    return summary


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def benchmark_static_markers(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {"files": {}, "tests": []}
    files = {
        "api_agent.php": ZEROTHINK_DIR / "api_agent.php",
        "api_cli.php": ZEROTHINK_DIR / "api_cli.php",
        "research-paper-creator.php": ZEROTHINK_DIR / "research-paper-creator.php",
    }
    sources = {name: read_text(path) for name, path in files.items()}
    for name, path in files.items():
        summary["files"][name] = {
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }

    marker_specs = [
        (
            "OpenZero agent endpoint route present",
            "api_agent.php",
            ["/v1/agent/runs", "zt_openzero_agent_run_request", "chat_completion_fallback"],
        ),
        (
            "OpenZero local model map present",
            "api_agent.php",
            ["zt_openzero_local_model_map", "glm4:9b-q5", "hermes3:8b-llama3.1-q5_K_M", "gemma4:e4b"],
        ),
        (
            "auth preflight blocks unauthenticated generation",
            "api_agent.php",
            ["Auth or supported direct key mode required", "$allow_direct_mode", "request_user_is_authenticated"],
        ),
        (
            "direct mode limited to supported providers",
            "api_agent.php",
            ["direct_mode", "['groq', 'nvidia']"],
        ),
        (
            "research paper workflow actions present",
            "research-paper-creator.php",
            [
                "search_protocol",
                "evidence_plan",
                "claim/evidence",
                "paper_outline",
                "full_research_paper",
                "survey_article",
            ],
        ),
        (
            "research paper full-draft validator present",
            "research-paper-creator.php",
            ["validateFullPaperOutput", "buildRepairPrompt", "Validator warning"],
        ),
        (
            "CLI device authorization protocol present",
            "api_cli.php",
            ["device_start", "device_poll", "authorization_pending", "request_bearer_token"],
        ),
    ]

    for test_name, file_name, markers in marker_specs:
        source = sources[file_name]
        missing = [marker for marker in markers if marker not in source]
        pass_ok = not missing
        details = {"required_markers": markers, "missing_markers": missing}
        add_result(
            rows,
            "static_code",
            test_name,
            file_name,
            "all required markers present",
            "present" if pass_ok else f"missing={missing}",
            pass_ok,
            None,
            details,
            [],
        )
        summary["tests"].append(details | {"name": test_name, "file": file_name, "passed": pass_ok})

    map_source = sources["api_agent.php"]
    block_match = re.search(r"function zt_openzero_local_model_map\(\).*?return\s+\[(.*?)\];", map_source, flags=re.S)
    model_values: list[str] = []
    if block_match:
        model_values = sorted(set(re.findall(r"=>\s*'([^']+)'", block_match.group(1))))
    summary["openzero_local_model_values"] = model_values
    return summary


def write_outputs(rows: list[dict[str, Any]], summary: dict[str, Any]) -> dict[str, Path]:
    ensure_dirs()
    csv_name = f"zerothink-system-benchmark-{RUN_DATE}.csv"
    json_name = f"zerothink-system-benchmark-summary-{RUN_DATE}.json"
    csv_paths = [WORK_RESULTS_DIR / csv_name, PUBLIC_RESULTS_DIR / csv_name]
    json_paths = [WORK_RESULTS_DIR / json_name, PUBLIC_RESULTS_DIR / json_name]

    fieldnames = [
        "run_date",
        "category",
        "test",
        "target",
        "expected",
        "observed",
        "passed",
        "latency_seconds",
        "secret_hits",
        "details_json",
    ]
    for path in csv_paths:
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    for path in json_paths:
        path.write_text(json.dumps(summary, indent=2, ensure_ascii=True, sort_keys=True) + "\n", encoding="utf-8")

    return {"csv": PUBLIC_RESULTS_DIR / csv_name, "json": PUBLIC_RESULTS_DIR / json_name}


def main() -> int:
    ensure_dirs()
    rows: list[dict[str, Any]] = []
    started = now_iso()

    public_summary = benchmark_public_pages(rows)
    cli_summary = benchmark_cli_api(rows)
    agent_summary = benchmark_agent_api(rows)
    static_summary = benchmark_static_markers(rows)

    total = len(rows)
    passed = sum(1 for row in rows if row["passed"] == "yes")
    failed = total - passed
    latency_rows = [float(row["latency_seconds"]) for row in rows if row["latency_seconds"]]
    secret_hit_rows = [row for row in rows if row["secret_hits"]]
    categories: dict[str, dict[str, Any]] = {}
    for row in rows:
        bucket = categories.setdefault(row["category"], {"total": 0, "passed": 0})
        bucket["total"] += 1
        if row["passed"] == "yes":
            bucket["passed"] += 1
    for bucket in categories.values():
        bucket["failed"] = bucket["total"] - bucket["passed"]
        bucket["pass_rate"] = bucket["passed"] / bucket["total"] if bucket["total"] else 0.0

    summary: dict[str, Any] = {
        "benchmark": "ZeroThink public system benchmark",
        "run_date": RUN_DATE,
        "generated_at_utc": now_iso(),
        "started_at_utc": started,
        "base_url": BASE_URL,
        "iterations_per_public_page": ITERATIONS,
        "total_tests": total,
        "passed_tests": passed,
        "failed_tests": failed,
        "pass_rate": passed / total if total else 0.0,
        "categories": categories,
        "latency_seconds": {
            "mean": statistics.mean(latency_rows) if latency_rows else None,
            "median": statistics.median(latency_rows) if latency_rows else None,
            "min": min(latency_rows) if latency_rows else None,
            "max": max(latency_rows) if latency_rows else None,
        },
        "secret_leak_checks": {
            "patterns": sorted(SECRET_PATTERNS.keys()),
            "rows_with_hits": len(secret_hit_rows),
            "passed": len(secret_hit_rows) == 0,
        },
        "public_pages": public_summary,
        "cli_api": cli_summary,
        "agent_api": agent_summary,
        "static_code": static_summary,
        "method_notes": [
            "No account cookies, real provider keys, or private server credentials were used.",
            "The direct identity/capabilities probes use a fake key and stop in ZeroThink local code before any external provider call.",
            "Unauthenticated generation is expected to be blocked; this benchmark records boundary correctness rather than bypassing auth.",
            "Model answer quality for Shafire/Spectra GGUFs is covered by the separate OpenZero API benchmark snapshot.",
        ],
    }
    outputs = write_outputs(rows, summary)
    print(json.dumps({"outputs": {key: str(value) for key, value in outputs.items()}, "summary": summary}, indent=2))
    return 0 if failed == 0 and not secret_hit_rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
